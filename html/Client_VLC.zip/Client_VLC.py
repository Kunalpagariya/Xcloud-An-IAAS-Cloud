#!/usr/bin/python2

import os
os.system("yum install openssh-clients")
os.system("ssh -X root@192.168.43.29 vlc")
